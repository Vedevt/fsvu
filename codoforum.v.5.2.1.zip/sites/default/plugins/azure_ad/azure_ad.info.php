<?php

$info['name'] = 'Azure AD';
$info['description'] = 'Integrate with Azure Active Directory';
$info['version'] = '1.x';
$info['author'] = "Adesh D'Silva";
$info['author_url'] = 'https://codoforum.com';
$info['license'] = 'GNU GPL V3';
$info['core'] = '1.x';
