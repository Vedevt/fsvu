<?php

$info['name'] = 'Ignis';
$info['description'] = 'The Fire-Red theme';
$info['version'] = '1.x';
$info['author'] = "Codologic";
$info['author_url'] = 'http://codologic.com';
$info['license'] = 'Core License';
$info['core'] = '1.x';
$info['parent_theme'] = 'default';