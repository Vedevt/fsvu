This place includes all default plugins, themes, images etc

Be aware that all assets included here are global, and therefore available to 
all other sites
