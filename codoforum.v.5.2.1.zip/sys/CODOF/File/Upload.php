<?php

/**
 * Upload helper class for working with uploaded files and [Validation].
 *
 *     $array = Validation::factory($_FILES);
 *
 * [!!] Remember to define your form with "enctype=multipart/form-data" or file
 * uploading will not work!
 *
 * The following configuration properties can be set:
 *
 * - [Upload::$remove_spaces]
 * - [Upload::$default_directory]
 *

  This license is a legal agreement between you and the Kohana Team for the use of Kohana Framework (the "Software"). By obtaining the Software you agree to comply with the terms and conditions of this license.
  Copyright © 2007–2013 Kohana Team. All rights reserved.
  Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
  Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
  Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
  Neither the name of the Kohana nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.
  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.


 * @author     Kohana Team
 * @copyright  (c) 2007-2012 Kohana Team
 * @license    http://kohanaframework.org/license
 */

namespace CODOF\File;

class Upload {

    public static $error = true;

    /**
     * @var  boolean  remove spaces in uploaded files
     */
    public static $remove_spaces = TRUE;
    public static $supportBmp = false;
    public static $width;
    public static $height;
    public static $resizeImage = false;
    public static $resizeIconSize = 50;
    public static $resizeIconPath = '';

    /**
     * @var  string  default upload directory
     */
    public static $default_directory = 'upload';

    /**
     * Save an uploaded file to a new location. If no filename is provided,
     * the original filename will be used, with a unique prefix added.
     *
     * This method should be used after validating the $_FILES array:
     *
     *     if ($array->check())
     *     {
     *         // Upload is valid, save it
     *         Upload::save($array['file']);
     *     }
     *
     * @param   array   $file       uploaded file data
     * @param   string  $filename   new filename
     * @param   string  $directory  new directory
     * @param   integer $chmod      chmod mask
     * @return  string  on success, full path to new file
     * @return  FALSE   on failure
     */
    public static function save(array $file, $filename = NULL, $directory = NULL, $chmod = 0644) {
        if (!isset($file['tmp_name']) OR ! is_uploaded_file($file['tmp_name'])) {
            // Ignore corrupted uploads
            return FALSE;
        }

        if ($filename === NULL) {
            // Use the default filename, with a timestamp pre-pended
            $filename = uniqid() . $file['name'];
        }

        if (Upload::$remove_spaces === TRUE) {
            // Remove spaces from the filename
            $filename = preg_replace('/\s+/u', '_', $filename);
        }

        if ($directory === NULL) {
            // Use the pre-configured upload directory
            $directory = Upload::$default_directory;
        }

        if (!is_dir($directory) OR ! is_writable(realpath($directory))) {
            \CODOF\Log::error("Upload directory not writable");
        }

        $resizer = new \Ext\ImageResize();

        // Make the filename into a complete path
        $file_info["name"] = $filename;
        $filename = realpath($directory) . DIRECTORY_SEPARATOR . $filename;
        $file_info["path"] = $filename;

        if (self::image($file) && self::$resizeImage) {

            $success = $resizer->smart_resize_image($file['tmp_name'], NULL, self::$width, self::$height, true, $filename, FALSE, FALSE, 75);

            if (self::$resizeIconPath != '') {

                $w = $h = self::$resizeIconSize;
                $iconPath = self::$resizeIconPath . $file_info["name"];
                $success = $resizer->smart_resize_image($file['tmp_name'], NULL, $w, $h, true, $iconPath, FALSE, FALSE, 75);
            }
        } else {

            $success = move_uploaded_file($file['tmp_name'], $filename);

            if (self::$resizeIconPath != '')
                @copy($filename, self::$resizeIconPath . $file_info["name"]);
        }

        if ($success) {

            if ($chmod !== FALSE) {
                // Set permissions on filename
                chmod($filename, $chmod);
            }

            // Return new file path
            return $file_info;
        }


        return FALSE;
    }

    /**
     * Tests if upload data is valid, even if no file was uploaded. If you
     * _do_ require a file to be uploaded, add the [Upload::not_empty] rule
     * before this rule.
     *
     *     $array->rule('file', 'Upload::valid')
     *
     * @param   array   $file   $_FILES item
     * @return  bool
     */
    public static function valid($file) {
        return (isset($file['error']) AND isset($file['name']) AND isset($file['type']) AND isset($file['tmp_name']) AND isset($file['size']));
    }

    /**
     * Tests if a successful upload has been made.
     *
     *     $array->rule('file', 'Upload::not_empty');
     *
     * @param   array   $file   $_FILES item
     * @return  bool
     */
    public static function not_empty(array $file) {
        return (isset($file['error']) AND isset($file['tmp_name']) AND $file['error'] === UPLOAD_ERR_OK AND is_uploaded_file($file['tmp_name']));
    }

    /**
     * Test if an uploaded file is an allowed file type, by extension.
     *
     *     $array->rule('file', 'Upload::type', array(':value', array('jpg', 'png', 'gif')));
     *
     * @param   array   $file       $_FILES item
     * @param   array   $allowed    allowed file extensions
     * @return  bool
     */
    public static function type(array $file, array $allowed) {
        if ($file['error'] !== UPLOAD_ERR_OK)
            return TRUE;

        $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));

        return in_array($ext, $allowed);
    }

    /**
     * Validation rule to test if an uploaded file is allowed by file size.
     * File sizes are defined as: SB, where S is the size (1, 8.5, 300, etc.)
     * and B is the byte unit (K, MiB, GB, etc.). All valid byte units are
     * defined in Num::$byte_units
     *
     *     $array->rule('file', 'Upload::size', array(':value', '1M'))
     *     $array->rule('file', 'Upload::size', array(':value', '2.5KiB'))
     *
     * @param   array   $file   $_FILES item
     * @param   string  $size   maximum file size allowed
     * @return  bool
     */
    public static function size(array $file, $size) {
        if ($file['error'] === UPLOAD_ERR_INI_SIZE) {
            // Upload is larger than PHP allowed size (upload_max_filesize)
            return FALSE;
        }

        if ($file['error'] !== UPLOAD_ERR_OK) {
            // The upload failed, no size to check
            return TRUE;
        }

        $size*=1024 * 1024; //Convert into MB
        // Test that the file is under or equal to the max size
        return ($file['size'] <= $size);
    }

    /**
     * Validation rule to test if an upload is an image and, optionally, is the correct size.
     *
     *     // The "image" file must be an image
     *     $array->rule('image', 'Upload::image')
     *
     *     // The "photo" file has a maximum size of 640x480 pixels
     *     $array->rule('photo', 'Upload::image', array(':value', 640, 480));
     *
     *     // The "image" file must be exactly 100x100 pixels
     *     $array->rule('image', 'Upload::image', array(':value', 100, 100, TRUE));
     *
     *
     * @param   array   $file       $_FILES item
     * @param   integer $max_width  maximum width of image
     * @param   integer $max_height maximum height of image
     * @param   boolean $exact      match width and height exactly?
     * @return  boolean
     */
    public static function image(array $file, $max_width = NULL, $max_height = NULL, $exact = FALSE) {
        if (Upload::not_empty($file)) {
            try {
                // Get the width and height from the uploaded image
                list($width, $height) = @getimagesize($file['tmp_name']);
            } catch (Exception $e) {
                // Ignore read errors
            }

            if (empty($width) OR empty($height)) {
                // Cannot get image size, cannot validate
                return FALSE;
            }

            if (!$max_width) {
                // No limit, use the image width
                $max_width = $width;
            }

            if (!$max_height) {
                // No limit, use the image height
                $max_height = $height;
            }

            if ($exact) {
                // Check if dimensions match exactly
                return ($width === $max_width AND $height === $max_height);
            } else {
                // Check if size is within maximum dimensions
                return ($width <= $max_width AND $height <= $max_height);
            }
        }

        return FALSE;
    }

    public static function do_upload($image, $path) {

        self::$error = true;

        if (!self::valid($image)) {

            return 'File is not valid';
        }

        if (!self::not_empty($image)) {

            return 'File is empty';
        }

        if (!self::size($image, (int) \CODOF\Util::get_opt('forum_attachments_size'))) {

            return 'File size too large';
        }

        $types = explode(",", \CODOF\Util::get_opt('forum_attachments_exts'));

        if (self::$supportBmp) {

            //add support for bmp
            array_merge($types, 'bmp');
        } else {

            $types = array_diff($types, array('bmp'));
        }


        if (!self::type($image, $types)) {

            return 'File extension type not supported';
        }

        self::$error = false;

        \CODOF\Hook::call('on_file_upload', array($image, $path));

        $ext = strtolower(pathinfo($image['name'], PATHINFO_EXTENSION));
        return self::save($image, uniqid() . "." . $ext, DATA_PATH . $path, 0777);
    }

}
