<?php

/*
 * @CODOLICENSE
 */

namespace CODOF\Booter\IoC;

class DB extends IoC{

    
    protected static function getComponentName() {
        
        return 'db';
    }
    
}
